package com.example.touchlock

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = TextView(this).apply {
            text = "Touch Lock\n\nقفل اللمس بزر رفع الصوت"
            textSize = 23f
            gravity = Gravity.CENTER
            setPadding(24, 32, 24, 20)
        }
        val info = TextView(this).apply {
            text = "الإعداد الأولي:\n1) فعّل خدمة Touch Lock من إعدادات إمكانية الوصول.\n2) اسمح بالظهور فوق التطبيقات الأخرى.\n3) ارجع إلى التطبيق. اضغط مطولاً زر رفع الصوت لمدة ثانيتين لقفل اللمس أو فتحه."
            textSize = 16f
            setPadding(24, 12, 24, 24)
        }
        val accessibility = Button(this).apply {
            text = "فتح إعدادات إمكانية الوصول"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        val overlay = Button(this).apply {
            text = "السماح بالظهور فوق التطبيقات"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(16, 20, 16, 20)
            addView(title)
            addView(info)
            addView(accessibility, LinearLayout.LayoutParams(-1, -2))
            addView(overlay, LinearLayout.LayoutParams(-1, -2))
        }
        setContentView(layout)
    }
}
