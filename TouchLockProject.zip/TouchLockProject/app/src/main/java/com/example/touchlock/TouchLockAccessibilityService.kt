package com.example.touchlock

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

class TouchLockAccessibilityService : AccessibilityService() {
    private var downAt = 0L
    private var volumeUpDown = false
    private var overlayView: View? = null
    private var locked = false
    private lateinit var windowManager: WindowManager

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        serviceInfo = serviceInfo.apply {
            flags = flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
        }
    }

override fun onKeyEvent(event: KeyEvent): Boolean {
    if (event.keyCode != KeyEvent.KEYCODE_VOLUME_UP) return false

    when (event.action) {
        KeyEvent.ACTION_DOWN -> {
            if (!volumeUpDown) {
                volumeUpDown = true
                downAt = SystemClock.uptimeMillis()
            }
            return false
        }

        KeyEvent.ACTION_UP -> {
            if (volumeUpDown) {
                val held = SystemClock.uptimeMillis() - downAt
                volumeUpDown = false

                if (held >= 2_000L) {
                    toggleLock()
                }
            }
            return false
        }
    }

    return false
}
private fun toggleLock() {
    if (locked) {
        unlockTouch()
    } else {
        lockTouch()
    }
}
    private fun lockTouch() {
        if (overlayView != null) return
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
            isFocusable = false
            setOnTouchListener { _, _ -> true }
        }
        val hint = TextView(this).apply {
            text = "اللمس مقفل\nاضغط مطولاً زر رفع الصوت لمدة ثانيتين للفتح"
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(16, 10, 16, 10)
            setBackgroundColor(0xAA202020.toInt())
        }
        val paramsHint = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL
        )
        root.addView(hint, paramsHint)

        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        try {
            windowManager.addView(root, params)
            overlayView = root
            locked = true
        } catch (_: Exception) {
            overlayView = null
            locked = false
        }
    }

    private fun unlockTouch() {
        overlayView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        overlayView = null
        locked = false
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() { unlockTouch() }

    override fun onDestroy() {
        unlockTouch()
        super.onDestroy()
    }
}

private object SettingsHelper {
    fun canDraw(service: AccessibilityService): Boolean =
        if (Build.VERSION.SDK_INT >= 23) android.provider.Settings.canDrawOverlays(service)
        else true
}
